package lu.uni.helloworld;

public class Launch {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		System.out.println("How are you ?");
		System.out.println("Test with sysout done !");
	}
}

