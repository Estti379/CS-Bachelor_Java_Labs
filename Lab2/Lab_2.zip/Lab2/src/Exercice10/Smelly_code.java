package Exercice10;

public class Smelly_code {

	public static void main(String[] args) {
		String Smelly_cat = "smelly cat";
		System.out.println("this is just a test:"+Smelly_cat);
		System.out.println("this is just a test2:"+Smelly_cat);
		System.out.println("this is just a test3:"+Smelly_cat);
	}

}
