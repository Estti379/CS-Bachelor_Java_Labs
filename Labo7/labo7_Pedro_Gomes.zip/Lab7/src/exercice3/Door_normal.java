package exercice3;

public class Door_normal extends Door{
	
	public Door_normal() {}

	public boolean isDoorOpen() {
		return true;
	}
}
