package exercice3;

public abstract class Door {
	
	public Door() {}
	
	public abstract boolean isDoorOpen();
	
}
